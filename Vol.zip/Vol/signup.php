<?php
include 'db_connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["fullname"]);
    $email = trim($_POST["email"]);
    $password = password_hash(trim($_POST["password"]), PASSWORD_DEFAULT);
    $userType = trim($_POST["role"]);

    if (!$username || !$email || !$password || !$userType) {
        die("Error: All fields are required!");
    }

    // Validate the user type and assign the correct table name
    if ($userType === "admin") {
        $table = "admins"; // Correct table name
    } elseif ($userType === "volunteer") {
        $table = "volunteers"; // Correct table name
    } else {
        die("Error: Invalid user type!");
    }

    // Prepare the SQL query with a fixed table name
    $sql = "INSERT INTO $table (fullname, email, password) VALUES (?, ?, ?)";

    // Execute the query
    if ($stmt = $conn->prepare($sql)) {
        $stmt->bind_param("sss", $username, $email, $password);
        if ($stmt->execute()) {
            echo "success";
            header("Location: login.html");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
        $stmt->close();
    } else {
        echo "SQL Error: " . $conn->error;
    }

    $conn->close();
}
?>
