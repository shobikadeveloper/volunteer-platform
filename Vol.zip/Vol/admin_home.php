<?php
include 'db_connect.php';
session_start();

// Check if the user is logged in and is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== "admin") {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Admin - Manage Opportunities</title>
  <link rel="stylesheet" href="home.css">
</head>
<body>
  <header>
    <div class="navbar">x`
      <h1>Admin Dashboard</h1>
      <nav>
        <ul>
          <li><a href="admin_home.php">Home</a></li>
          <li><a href="add.php">Add Opportunity</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main>
    <section id="opportunities">
      <h2>Manage Opportunities</h2>
      <div id="opportunity-list">
        <?php
        $sql = "SELECT * FROM opportunities";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
          echo "<div class='opportunity-card'>
                  <h3>{$row['title']}</h3>
                  <p>{$row['description']}</p>
                  <p><strong>Skills:</strong> {$row['skills']}</p>
                  <p><strong>Location:</strong> {$row['location']}</p>
                  <p><strong>Organization:</strong> {$row['organization']}</p>
                  <p><strong>Hours Needed:</strong> {$row['hours']} hours</p>
                  <form action='delete.php' method='POST'>
                    <input type='hidden' name='id' value='{$row['id']}'>
                    <button type='submit' class='delete-btn'>Delete</button>
                  </form>
                </div>";
        }
        ?>
      </div>
    </section>
  </main>
</body>
</html>
