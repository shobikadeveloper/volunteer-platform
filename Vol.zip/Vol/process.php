<?php
include 'db_connect.php';
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $title = trim($_POST['title']);
    $description = trim($_POST['description']);
    $skills = trim($_POST['skills']);
    $location = trim($_POST['location']);
    $organization = trim($_POST['organization']);
    $hours = intval($_POST['hours']);

    // Validate form inputs
    if (empty($title) || empty($description) || empty($skills) || empty($location) || empty($organization) || $hours <= 0) {
        die("Error: All fields are required and must be valid!");
    }

    // Insert into database
    $stmt = $conn->prepare("INSERT INTO opportunities (title, description, skills, location, organization, hours) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssi", $title, $description, $skills, $location, $organization, $hours);

    if ($stmt->execute()) {
        // Redirect back to home.php after successful insertion
        header("Location: admin_home.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
