<?php
include 'db_connect.php';
session_start();

// Check if the user is logged in and is a volunteer
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== "volunteer") {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Volunteer - View Opportunities</title>
  <link rel="stylesheet" href="home.css">
</head>
<body>
  <header>
    <div class="navbar">
      <h1>Volunteer Dashboard</h1>
      <nav>
        <ul>
          <li><a href="volunteer_home.php">Home</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <main>
    <section id="opportunities">
      <h2>Available Opportunities</h2>
      <div id="opportunity-list">
        <?php
        $sql = "SELECT * FROM opportunities";
        $result = $conn->query($sql);
        while ($row = $result->fetch_assoc()) {
          echo "<div class='opportunity-card'>
                  <h3>{$row['title']}</h3>
                  <p>{$row['description']}</p>
                  <p><strong>Skills:</strong> {$row['skills']}</p>
                  <p><strong>Location:</strong> {$row['location']}</p>
                  <p><strong>Organization:</strong> {$row['organization']}</p>
                  <p><strong>Hours Needed:</strong> {$row['hours']} hours</p>
                </div>";
        }
        ?>
      </div>
    </section>
  </main>
</body>
</html>
