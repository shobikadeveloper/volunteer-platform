<?php
include 'db_connect.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $role = trim($_POST['userType']);

    if (!$email || !$password || !$role) {
        die("Error: All fields are required!");
    }

    // Validate user type and set correct table name
    if ($role === "admin") {
        $table = "admins"; // Correct table name
    } elseif ($role === "volunteer") {
        $table = "volunteers"; // Correct table name
    } else {
        die("Error: Invalid user type!");
    }

    // Prepare and execute the query
    $stmt = $conn->prepare("SELECT id, password FROM $table WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        if (password_verify($password, $row['password'])) {
            $_SESSION['user_id'] = $row['id'];
            $_SESSION['role'] = $role;

            // Redirect based on role
            if ($role === "admin") {
                header("Location: admin_home.php");
            } else {
                header("Location: volunteer_home.php");
            }
            exit();
        } else {
            echo "Invalid password!";
        }
    } else {
        echo "No user found with this email.";
    }

    $stmt->close();
    $conn->close();
}
?>
