<?php
include 'db_connect.php';
session_start();

// Check if user is an admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== "admin") {
    die("Unauthorized action.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];

    $stmt = $conn->prepare("DELETE FROM opportunities WHERE id = ?");
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "Opportunity deleted!";
        header("Location: admin_home.php");
    } else {
        echo "Error deleting record: " . $conn->error;
    }
    $stmt->close();
    $conn->close();
}
?>
