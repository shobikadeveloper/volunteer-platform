document.addEventListener("DOMContentLoaded", function () {
    let loginForm = document.getElementById("loginForm");

    if (loginForm) {
        loginForm.addEventListener("submit", function (e) {
            e.preventDefault();
            let email = document.getElementById("email").value;
            let password = document.getElementById("password").value;
            let userType = document.getElementById("userType").value;

            fetch("login.php", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: `email=${email}&password=${password}&userType=${userType}`
            })
            .then(response => response.text())
            .then(data => {
                if (data.trim() === "success") {
                    window.location.href = (userType === "volunteer") ? "volunteerHome.php" : "adminHome.php";
                } else {
                    alert(data);
                }
            });
        });
    }
});
