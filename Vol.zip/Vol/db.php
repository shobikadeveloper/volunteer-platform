<?php
function getDBConnection($userType) {
    $host = "localhost";
    $user = "root";
    $password = "";

    if ($userType === "volunteer") {
        $dbname = "volunteers_db";
    } else {
        $dbname = "admin_db";
    }

    $conn = new mysqli($host, $user, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    return $conn;
}
?>
