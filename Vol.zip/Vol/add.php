<?php
include 'db_connect.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: index.html");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
  <title>Add Opportunity</title>
  <link rel="stylesheet" href="home.css">
</head>
<body>
  <header>
    <div class="navbar">
      <h1>Add Volunteer Opportunity</h1>
      <nav>
        <ul>
          <li><a href="home.php">Home</a></li>
          <li><a href="logout.php">Logout</a></li>
        </ul>
      </nav>
    </div>
  </header>

  <h2 class="headings">Add a New Opportunity</h2>
  <div class="flexCont">
  <form action="process.php" method="POST" class="forms">
    <div>
        <label>Title:</label>
        <input type="text" name="title" placeholder="Title" required>
    </div>
    <div>
        <label>Description:</label>
        <textarea name="description" placeholder="Description" required></textarea>
    </div>
    <div>
        <label>Skills:</label>
        <input type="text" name="skills" placeholder="Skills" required>
    </div>
    <div>
        <label>Location:</label>
        <input type="text" name="location" placeholder="Location" required>
    </div>
    <div>
        <label>Organization:</label>
        <input type="text" name="organization" placeholder="Organization" required>
    </div>
    <div>
        <label>Hours Needed:</label>
        <input type="number" name="hours" placeholder="Hours" required>
    </div>
    <div>
        <button type="submit" class="Btn">Add Opportunity</button>
    </div>
  </form>
  </div>
</body>
</html>
